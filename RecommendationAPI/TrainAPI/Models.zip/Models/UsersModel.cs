﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TrainAPI.Models
{
    public class UsersModel
    {
        public int id_film { get; set; }

        public string id_info { get; set; }

        public int evaluate { get; set; }
    }
}
